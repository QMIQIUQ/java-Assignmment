/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversions.between.celsius.and.fahrenheit;

/**
 *
 * @author Jackson Ang D190104B 28/05/2019
 * Conversions between Celsius and Fahrenheit
 */
public class ConversionsBetweenCelsiusAndFahrenheit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double celsius = 40;
        double fahrenheit = 120;
        double a,b;
        System.out.print("Celsius\t\tFahrenheit\t|\tFahrenheit\tCelsius\n");
        System.out.println("_______________________________________________________________");
        for(int c=1;c<11;c++){
        a = celsiusToFahrenheit(celsius);
        b = fahrenheitToCelsius(fahrenheit);
        System.out.print(celsius+"\t\t");
        System.out.printf("%-1.2f\t\t|\t",a);
        System.out.print(fahrenheit+"\t\t");
        System.out.printf("%-1.2f\n",b);
        celsius--;
        fahrenheit-=10;
        }
    }
    public static double celsiusToFahrenheit(double celsius){
        double fahrenheit = (9.0 / 5) * celsius + 32;
        return fahrenheit;
    } 
    
    public static double fahrenheitToCelsius(double fahrenheit){
        double celsius =(5.0 / 9)*(fahrenheit - 32); 
        return celsius;
        
    }
}
