/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scissorrockpapergame;

/**
 *
 * @author Jackson Ang D190104B 2019/05/13
 * rock paper scissor game~~
 */
import java.util.*;
public class ScissorRockPaperGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int computer = (int)(Math.random()*3);
    System.out.print("scissor(0),rock(1),paper(2): ");
    int player = input.nextInt();
    switch (computer){
        case 0 : System.out.print("The computer is scissor. ");break;
        case 1 : System.out.print("The computer is rock. ");break;
        case 2 : System.out.print("The computer is paper. ");break;
    }
    switch(player){
        case 0 : if(computer == 2){
                    System.out.print("You are Scessor. You win\n");
                }else{
                if(computer == 1){
                    System.out.print("You are Scessor. You lose\n");
                }else{
                System.out.print("You are Scessor too. It is a draw\n");
                }
                };break;
        case 1 :  if(computer == 0){
                    System.out.print("You are rock. You win\n");
                }else{
                if(computer == 2){
                    System.out.print("You are rock. You lose\n");
                }else{
                System.out.print("You are rock too. It is a draw\n");
                }
                };break;
        case 2 :  if(computer == 1){
                    System.out.print("You are paper. You win\n");
                }else{
                if(computer == 0){
                    System.out.print("You are paper. You lose\n");
                }else{
                System.out.print("You are paper too. It is a draw\n");
                }
                };break;
    }
            }
            
    
    }
    
