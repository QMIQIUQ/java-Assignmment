/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author MIQIU
 */
public class MainPiza extends Application {

    ArrayList orderPizza = new ArrayList();
    String name, phoneNumber, memberID;
    int size, pizaCount = 0, memberPoints, countfile = 0;
    boolean[] toppings = new boolean[3];
    String address;
    boolean member;
    double totalPrics;

    Scene scene;
    BorderPane root = new BorderPane();
    TextField memberIDTextField = new TextField(),
            nameTextFill = new TextField(), phoneNumberTextFiled = new TextField(),
            addresstextField = new TextField(), postCodeTextField = new TextField(), cityTextField = new TextField(), stateTextfield = new TextField(),
            payTextField = new TextField();
    Button startButton = new Button("Take ME There!!"),
            memberNextButton = new Button("Next>"),
            nameNextButton = new Button("Next>"),
            nextToppingButton = new Button("Next>>"),
            nextAddressButton = new Button("Next>>"),
            checkOutReciptButton = new Button("CheckOut>>"), orderAgeinButton = new Button("<<OrderAgein"),
            payButton = new Button("Pay");
    StackPane lPizzaSP = new StackPane(), mPizzaSP = new StackPane(), sPizzaSP = new StackPane(),
            pepperoniSP = new StackPane(), sausageSP = new StackPane(), mushroomSP = new StackPane();
    Image tick = new Image("file:resources/tick.png");
    ImageView tickImageView1 = new ImageView(tick), tickImageView3 = new ImageView(tick), tickImageView2 = new ImageView(tick);
    boolean click1 = false, click2 = false, click3 = false;
    ListView orderListView = new ListView();

    private void recipt() {
        VBox center = new VBox();
        center.setSpacing(5);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text text = new Text("Recipt");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

        StackPane mid = new StackPane();
        mid.setMinHeight(200);

        VBox vb = new VBox();
        StackPane sp = new StackPane();
        GridPane midGP = new GridPane();

        for (int i = 0; i < orderPizza.size(); i++) {

            totalPrics += calculateTotalPrice(orderPizza.get(i));

        }

        Text text1 = new Text("Total Price: ");
        text1.setFont(Font.font(30));
        Text text2 = new Text("RM " + totalPrics);
        text2.setFont(Font.font(30));
        Text text3 = new Text("You Paid :");
        text3.setFont(Font.font(30));
        payTextField.setPrefHeight(35);
        payTextField.setPromptText("Insert your amount here");

        midGP.add(text1, 0, 0);
        midGP.add(text2, 1, 0);
        midGP.add(text3, 0, 1);
        midGP.add(payTextField, 1, 1);

        sp.getChildren().add(midGP);
        vb.getChildren().addAll(orderListView, sp);
        mid.getChildren().add(vb);

        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        payButton.setMinSize(100, 40);
        hb.getChildren().addAll(payButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void cart() {
        VBox center = new VBox();
        center.setSpacing(5);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text text = new Text("Cart");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

        StackPane mid = new StackPane();

        mid.setMinHeight(200);
        mid.getChildren().add(orderListView);

        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        checkOutReciptButton.setMinSize(100, 40);
        orderAgeinButton.setMinSize(100, 40);
        hb.getChildren().addAll(orderAgeinButton, checkOutReciptButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void insertAddress() {

        VBox center = new VBox();
        center.setSpacing(40);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text Text = new Text("Please Enter Your Address");
        Text.setFont(Font.font(30));
        top.getChildren().add(Text);

        StackPane mid = new StackPane();
        mid.setMinHeight(200);
        VBox VB = new VBox();
        VB.setSpacing(30);
        HBox HB1 = new HBox();
        HB1.setSpacing(10);
        Text addressText = new Text("Address:");
        addressText.setFont(Font.font(30));
        addresstextField.setPrefHeight(35);
        addresstextField.setPromptText("Address");
        HB1.getChildren().addAll(addressText, addresstextField);

        HBox HB2 = new HBox();
        HB2.setSpacing(10);
        Text postcodeText = new Text("PostCode:");
        postcodeText.setFont(Font.font(30));
        postCodeTextField.setPrefHeight(35);
        postCodeTextField.setPromptText("PostCode:");
        HB2.getChildren().addAll(postcodeText, postCodeTextField);

        Text cityText = new Text("City:");
        cityText.setFont(Font.font(30));
        cityTextField.setPrefHeight(35);
        cityTextField.setPromptText("City");

        Text stateText = new Text("State:");
        stateText.setFont(Font.font(30));
        stateTextfield.setPrefHeight(35);
        stateTextfield.setPromptText("State");

        HBox HB3 = new HBox();
        HB3.setSpacing(10);
        HB3.getChildren().addAll(cityText, cityTextField, stateText, stateTextfield);
        VB.getChildren().addAll(HB1, HB2, HB3);
        mid.getChildren().add(VB);

        StackPane bottom = new StackPane();
        nextAddressButton.setMinSize(100, 40);
        bottom.getChildren().add(nextAddressButton);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);

    }

    private void selectToppings() {
        click1 = false;
        click2 = false;
        click3 = false;

        VBox center = new VBox();
        center.setSpacing(40);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text title = new Text("Add On Toppings?");
        title.setFont(Font.font(30));
        top.getChildren().add(title);

        StackPane mid = new StackPane();
        mid.setMinHeight(200);

        HBox centerHB = new HBox();

        centerHB.setSpacing(35);

        VBox VB1 = new VBox();
        Text priceText1 = new Text("RM 2");
        priceText1.setFont(Font.font(25));
        Image pepperoniImage = new Image("file:resources/pepperoni.png");
        ImageView ImageView1 = new ImageView(pepperoniImage);
        ImageView1.setFitHeight(130);
        ImageView1.setFitWidth(130);

        tickImageView1.setFitHeight(130);
        tickImageView1.setFitWidth(130);
        pepperoniSP.getChildren().clear();
        pepperoniSP.getChildren().addAll(ImageView1, tickImageView1);
        tickImageView1.setVisible(false);

        Text papperoniText = new Text("Pepperoni");
        papperoniText.setFont(Font.font(30));
        VB1.setAlignment(Pos.CENTER);
        VB1.getChildren().addAll(priceText1, pepperoniSP, papperoniText);

        VBox VB2 = new VBox();
        Text priceText2 = new Text("RM 2");
        priceText2.setFont(Font.font(25));
        Image sausageImage = new Image("file:resources/sausage.png");
        ImageView ImageView2 = new ImageView(sausageImage);
        ImageView2.setFitHeight(130);
        ImageView2.setFitWidth(130);

        tickImageView2.setFitHeight(130);
        tickImageView2.setFitWidth(130);
        sausageSP.getChildren().clear();
        sausageSP.getChildren().addAll(ImageView2, tickImageView2);
        tickImageView2.setVisible(false);

        Text sausageText = new Text("Sausage");
        sausageText.setFont(Font.font(30));
        VB2.setAlignment(Pos.CENTER);
        VB2.getChildren().addAll(priceText2, sausageSP, sausageText);

        VBox VB3 = new VBox();
        Text priceText3 = new Text("RM 2");
        priceText3.setFont(Font.font(25));
        Image mussroomImage = new Image("file:resources/mussroom.png");
        ImageView ImageView3 = new ImageView(mussroomImage);
        ImageView3.setFitHeight(130);
        ImageView3.setFitWidth(130);

        tickImageView3.setFitHeight(130);
        tickImageView3.setFitWidth(130);
        mushroomSP.getChildren().clear();
        mushroomSP.getChildren().addAll(ImageView3, tickImageView3);
        tickImageView3.setVisible(false);

        Text mussroomText = new Text("Mussroom");
        mussroomText.setFont(Font.font(30));
        VB3.setAlignment(Pos.CENTER);
        VB3.getChildren().addAll(priceText3, mushroomSP, mussroomText);
        centerHB.getChildren().addAll(VB1, VB2, VB3);
        mid.getChildren().add(centerHB);

        StackPane bottom = new StackPane();
        nextToppingButton.setMinSize(100, 40);
        bottom.getChildren().add(nextToppingButton);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void selectPizaSize() {
        VBox center = new VBox();
        center.setSpacing(40);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text title = new Text("Select Pizza Size");
        title.setFont(Font.font(30));
        top.getChildren().add(title);

        StackPane mid = new StackPane();
        mid.setMinHeight(200);

        HBox centerHB = new HBox();

        centerHB.setSpacing(35);

        VBox VB1 = new VBox();
        Text priceText1 = new Text("RM 12");
        priceText1.setFont(Font.font(25));
        Image Image1 = new Image("file:resources/largePizza.png");
        ImageView ImageView1 = new ImageView(Image1);
        ImageView1.setFitHeight(140);
        ImageView1.setFitWidth(140);

        lPizzaSP.getChildren().add(ImageView1);

        Text largeText = new Text("Large");
        largeText.setFont(Font.font(30));
        VB1.setSpacing(5);
        VB1.setAlignment(Pos.CENTER);
        VB1.getChildren().addAll(priceText1, lPizzaSP, largeText);

        VBox VB2 = new VBox();
        Text priceText2 = new Text("RM 10");
        priceText2.setFont(Font.font(25));
        Image Image2 = new Image("file:resources/mediumPizza.png");
        ImageView ImageView2 = new ImageView(Image2);
        ImageView2.setFitHeight(140);
        ImageView2.setFitWidth(140);

        mPizzaSP.getChildren().add(ImageView2);

        Text mediumText = new Text("Medium");
        mediumText.setFont(Font.font(30));
        VB2.setSpacing(5);
        VB2.setAlignment(Pos.CENTER);
        VB2.getChildren().addAll(priceText2, mPizzaSP, mediumText);

        VBox VB3 = new VBox();
        Text priceText3 = new Text("RM 8");
        priceText3.setFont(Font.font(25));
        Image Image3 = new Image("file:resources/smallPizza.png");
        ImageView ImageView3 = new ImageView(Image3);
        ImageView3.setFitHeight(140);
        ImageView3.setFitWidth(140);

        sPizzaSP.getChildren().add(ImageView3);

        Text smallText = new Text("Small");
        smallText.setFont(Font.font(30));
        VB3.setAlignment(Pos.CENTER);
        VB3.setSpacing(5);
        VB3.getChildren().addAll(priceText3, sPizzaSP, smallText);
        centerHB.getChildren().addAll(VB1, VB2, VB3);
        mid.getChildren().add(centerHB);

        center.getChildren().addAll(top, mid);
        root.setCenter(center);

    }

    private void insertName() {
        VBox center = new VBox();
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);

        StackPane mid = new StackPane();
        mid.setMinHeight(250);

        VBox centerVB = new VBox();

        centerVB.setSpacing(20);
        Text nameText = new Text("Please Enter Your Name:");
        nameText.setFont(Font.font(30));
        nameTextFill.setPrefHeight(35);
        nameTextFill.setPromptText("Name Here!");

        Text phoneNumberText = new Text("Please Enter Your Phone Number:");
        phoneNumberText.setFont(Font.font(30));
        phoneNumberTextFiled.setPrefHeight(35);
        phoneNumberTextFiled.setPromptText("Phone Number Here!");

        centerVB.getChildren().addAll(nameText, nameTextFill, phoneNumberText, phoneNumberTextFiled, nameNextButton);
        mid.getChildren().addAll(centerVB);

        StackPane bottom = new StackPane();
        nameNextButton.setMinSize(100, 40);
        bottom.getChildren().add(nameNextButton);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void isMember() {
        VBox center = new VBox();
        center.setSpacing(5);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text text = new Text("Are You a Member of us?");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

        StackPane mid = new StackPane();
        mid.setMinHeight(200);

        VBox VB = new VBox();
        VB.setSpacing(30);

        StackPane sp = new StackPane();
        Text Text1 = new Text("Enter member ID: ");
        sp.getChildren().add(Text1);

        Text1.setFont(Font.font(30));
        memberIDTextField.setPrefHeight(35);
        memberIDTextField.setPromptText("Enter your ID here!");

        StackPane sp1 = new StackPane();
        Text Text2 = new Text("if not, feel free to continue~");
        Text2.setFont(Font.font(30));
        sp1.getChildren().add(Text2);

        VB.getChildren().addAll(sp, memberIDTextField, sp1);
        mid.getChildren().add(VB);

        StackPane bottom = new StackPane();
        memberNextButton.setMinSize(100, 40);
        bottom.getChildren().add(memberNextButton);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void Main() {
        VBox center = new VBox();
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text text = new Text("Start Order Now!!");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

        StackPane mid = new StackPane();
        mid.setMinHeight(200);

        StackPane bottom = new StackPane();
        startButton.setMinSize(180, 70);
        bottom.getChildren().add(startButton);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);

    }

    private void WelcomeMenu() {

        VBox welcomeVB = new VBox();
        welcomeVB.setStyle("-fx-background-color:FireBrick");
        StackPane WelcomeSP = new StackPane();
        StackPane welcomeSP = new StackPane();
        Text a = new Text("  Pizza  ");
        a.setFill(Color.WHITE);
        a.setFont(Font.font("Bauhaus 93", 75));
        WelcomeSP.getChildren().add(a);
        welcomeVB.getChildren().addAll(WelcomeSP, welcomeSP);
        root.setTop(welcomeVB);
    }

    public void Menu() {
        WelcomeMenu();
        Main();
        root.setStyle("-fx-background-color:AntiqueWhite");

    }

    @Override
    public void start(Stage primaryStage) {

        Menu();
        scene = new Scene(root);
        primaryStage.getIcons().add(new javafx.scene.image.Image("file:resources/PizzaLogo.png"));
        primaryStage.setTitle("Pizza");
        primaryStage.setScene(scene);
        primaryStage.setHeight(550);
        primaryStage.setWidth(550);
        primaryStage.show();
//take me there button Start

        startButton.setOnAction(e -> {
            isMember();

        });

//member
        memberNextButton.setOnAction(e -> {

            if (memberIDTextField.getText().isEmpty()) {
                insertName();
                member = false;
            } else if (!memberIDTextField.getText().isEmpty()) {
                try {
                    File file = new File("member.txt");
                    Scanner reader = new Scanner(file);

                    boolean br = false;
                    countfile = 0;
                    while (reader.hasNext()) {

                        String memberid = reader.nextLine();
                        countfile++;
                        if (memberIDTextField.getText().equals(memberid)) {
                            br = true;
                            memberID = memberid;
                            memberPoints = reader.nextInt();
                            break;
                        }

                    }
                    if (br) {

                        member = true;
                        JOptionPane.showMessageDialog(null, " id found, your points = " + memberPoints);
                        insertName();

                    } else if (!br) {
                        JOptionPane.showMessageDialog(null, " invalid member ID! ");
                    }

                } catch (FileNotFoundException fnf) {
                    JOptionPane.showMessageDialog(null, " file not found! ");
                }
            }

        });

//enter name and phone number
        nameNextButton.setOnAction(e -> {
            if (nameTextFill.getText().isEmpty() || phoneNumberTextFiled.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Pless fill all the Information");
            } else {
                name = nameTextFill.getText();
                phoneNumber = phoneNumberTextFiled.getText();
                selectPizaSize();
            }
        });

//piza size selection
        lPizzaSP.setOnMouseClicked(e -> {
            size = 0;
            selectToppings();

        });

        mPizzaSP.setOnMouseClicked(e -> {
            size = 1;
            selectToppings();

        });

        sPizzaSP.setOnMouseClicked(e -> {
            size = 2;
            selectToppings();

        });

//piza toppings
        pepperoniSP.setOnMouseClicked(e -> {

            if (click1 == false) {
                tickImageView1.setVisible(true);
                click1 = true;

            } else if (click1 == true) {
                tickImageView1.setVisible(false);
                click1 = false;
            }

        });

        sausageSP.setOnMouseClicked(e -> {
            if (click2 == false) {
                tickImageView2.setVisible(true);
                click2 = true;
            } else if (click2 == true) {
                tickImageView2.setVisible(false);
                click2 = false;
            }

        });

        mushroomSP.setOnMouseClicked(e -> {
            if (click3 == false) {
                tickImageView3.setVisible(true);
                click3 = true;
            } else if (click3 == true) {
                tickImageView3.setVisible(false);
                click3 = false;
            }
        });

        nextToppingButton.setOnAction(e -> {
            toppings[0] = click1;
            toppings[1] = click2;
            toppings[2] = click3;
            insertAddress();

        });

//set address
        nextAddressButton.setOnAction(e -> {

            if (addresstextField.getText().isEmpty() || postCodeTextField.getText().isEmpty() || cityTextField.getText().isEmpty() || stateTextfield.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Pless fill all the Information");
            } else {
                address = addresstextField.getText() + ", " + postCodeTextField.getText() + ", " + cityTextField.getText() + ", " + stateTextfield.getText();
                orderedPizza pizza = new orderedPizza(name, phoneNumber, size, toppings, address);
                orderPizza.add(pizza);

                HBox hb1 = new HBox(300);
                GridPane gp = new GridPane();
                Text text = new Text(pizza.getName());
                text.setFont(Font.font(15));
                Text text1 = new Text(pizza.getSize());
                text1.setFont(Font.font(15));

                boolean a[] = pizza.getToppings();
                Text text2;
                if (a[0]) {
                    text2 = new Text("pepperoni = YES");
                } else {
                    text2 = new Text("pepperoni = NO");
                }
                text2.setFont(Font.font(15));

                Text text3;
                if (a[1]) {
                    text3 = new Text("sausage = YES");
                } else {
                    text3 = new Text("sausage = NO");
                }
                text3.setFont(Font.font(15));

                Text text4;
                if (a[2]) {
                    text4 = new Text("mushroom = YES");
                } else {
                    text4 = new Text("mushroom = NO");
                }
                text4.setFont(Font.font(15));

                Text text5 = new Text(addresstextField.getText());
                text5.setFont(Font.font(15));
                Text text6 = new Text(postCodeTextField.getText());
                text6.setFont(Font.font(15));
                Text text7 = new Text(cityTextField.getText() + ", " + stateTextfield.getText());
                text7.setFont(Font.font(15));

                Text text8 = new Text(pizza.calculatePrice());
                text8.setFont(Font.font(15));

                gp.add(text, 0, 0);
                gp.add(text1, 1, 0);
                gp.add(text2, 2, 0);
                gp.add(text3, 2, 1);
                gp.add(text4, 2, 2);
                gp.add(text5, 3, 0);
                gp.add(text6, 3, 1);
                gp.add(text7, 3, 2);
                gp.add(text8, 4, 0);

                gp.setHgap(30);
                hb1.setAlignment(Pos.CENTER_LEFT);
                hb1.setPrefWidth(500);
                hb1.getChildren().addAll(gp);
                orderListView.getItems().add(hb1);

                pizaCount += 1;
                cart();
            }

        });

//recept order again!!
        orderAgeinButton.setOnAction(e -> {
            int a = JOptionPane.showConfirmDialog(null, "Order Another Piza?", "confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (a == JOptionPane.YES_OPTION) {
                selectPizaSize();
            }

        });

        checkOutReciptButton.setOnAction(e -> {
            int a = JOptionPane.showConfirmDialog(null, "CheckOut?", "confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (a == JOptionPane.YES_OPTION) {
                recipt();
            }

        });

//pay
        payButton.setOnAction(e -> {
            double r = 0;

            if (payTextField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Pless fill all the Information");

            } else if (Double.parseDouble(payTextField.getText()) < totalPrics) {
                JOptionPane.showMessageDialog(null, "price need more than RM" + totalPrics);
            } else if (Double.parseDouble(payTextField.getText()) >= totalPrics) {
                r = Double.parseDouble(payTextField.getText()) - totalPrics;

                if (member) {
                    JOptionPane.showMessageDialog(null, "sucessful paid! Change RM " + r + "\nYour Current Points:" + (memberPoints + totalPrics));
                   
                    try {
                        File file = new File("member.txt");
                        Scanner myReader = new Scanner(file);
                        ArrayList old = new ArrayList();
                        while (myReader.hasNextLine()) {
                            old.add(myReader.nextLine());
                        }
                        myReader.close();
                        
                        old.set(countfile, (memberPoints+totalPrics));
                        FileWriter writer = new FileWriter(file);
                        PrintWriter writePR = new PrintWriter(writer);
                        for(int i = 0;i<old.size();i++){
                            writePR.println(old.get(i));
                        }
                        writePR.close();
                        writer.close();
                    } catch (FileNotFoundException fnf) {
                        System.out.println("An error occurred.");
                        fnf.printStackTrace();
                    }catch(IOException ioe){
                        
                    }
                    

                } else {
                    JOptionPane.showMessageDialog(null, "sucessful paid! Change RM " + r);
                }

                int a = JOptionPane.showConfirmDialog(null, "Start a new Order or exit?", "confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (a == JOptionPane.YES_OPTION) {

                    Main();
                    orderPizza.clear();

                } else if (a == JOptionPane.NO_OPTION) {
                    System.exit(0);
                }
            }

        });

    }

    public static double calculateTotalPrice(Object x) {
        double a = 0;
        if (x instanceof orderedPizza) {
            a = ((orderedPizza) x).getTotalprice();
        }
        return a;
    }
    
    public static String testing(Object x) {
        String a = "";
        if (x instanceof String) {
            a = x.toString();
        }
        return a;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
