/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;

/**
 *
 * @author dogaa
 */
import java.util.*;
public class Menu {
    public static void Menu(boolean[] state){
        System.out.println("------------------------------------------------");
        System.out.println("\t\t-= MMX Car =- \nBest place to find the car that Suitable for you");
        System.out.println("------------------------------------------------");
        System.out.println("\t\t   Welcome!");
        Menu1(state);
    }
    public static void Menu1(boolean[] state){
         Scanner input = new Scanner(System.in);
        int a = 0;
    
        while(a<1 || a>3){
        System.out.println("What would you lilke to do?");
        System.out.println("pls chose 1 , 2 or 3");
        System.out.println("1. Book a car now!\t\t 3.Exit\n2. View car list and the price!" );
        
        System.out.print("________________________________________________\nYou chose>: ");
        a = input.nextInt();
        switch(a){
            case 1 : promotion.promotion();break;
            case 2 : Cars.Cars(state);break;
            case 3 : System.out.println("------------------------------------------------");
                     exit(state);
            default : System.out.println("------------------------------------------------");
                      System.out.println("!invalid input,plese enter again!");
                      System.out.println("------------------------------------------------");break;
        }    
        }    
    }
    
        
    
    public static void exit(boolean[] state){
        Scanner input = new Scanner(System.in);
        int a;
        String exit1 = "YES";
        String exit3 = "NO";
        System.out.println("Do you really want to Exit?\nType\"YES\"to exit \"NO\"for Menu");
        String exit2 = input.nextLine();
        System.out.println("------------------------------------------------");
        
        if(exit2.equals(exit1)){
            System.out.println("QAQ bye...");
            System.out.println("------------------------------------------------");
            System.exit(0);
        }else
        {if(exit2.equals(exit3)){
            System.out.println("------------------------------------------------");
            Menu1(state);
            
        }else{
            System.out.println("!invalid input,plese enter again!");
            System.out.println("------------------------------------------------");
            Menu1(state);
        }
    }
    }
}

    
