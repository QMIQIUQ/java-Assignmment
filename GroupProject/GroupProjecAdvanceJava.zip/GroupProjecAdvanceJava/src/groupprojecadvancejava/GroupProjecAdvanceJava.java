/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupprojecadvancejava;

import java.time.LocalDate;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author MIQIU
 */
public class GroupProjecAdvanceJava extends Application {

    User user[] = new User[100];
    Booking booking[] = new Booking[100];
    int countBooking = 0;
    int countUser = 0;
    int userTemp = 0;
    double Price;
    boolean seat[] = new boolean[18];
    boolean Seat[] = new boolean[18];

    Scene scene;
    BorderPane root = new BorderPane();

    Text userName = new Text("UserName"),
            price = new Text("Price");
    PasswordField passwordTextField = new PasswordField(),
            registerPasswordTextField = new PasswordField(),
            registerRenterPasswordTextField = new PasswordField();

    TextField userTextField = new TextField(),
            userRegisterTextField = new TextField();

    ComboBox locationComboBox = new ComboBox(),
            distinationComboBox = new ComboBox(),
            time = new ComboBox();

    DatePicker date = new DatePicker();

    //Date dateNow = new Date();
    //LocalDate value = date.getValue();
    Button //loginPage 
            loginButton = new Button("Login"),
            registerButton = new Button("Register"),
            //registerPage 
            confirmRegisterButton = new Button("Register Now"),
            backToLoginButton = new Button("Back to Login"),
            //userMenu
            startBookingButton = new Button("Book Now!"),
            viewHistoryButton = new Button("View History"),
            logoutButton = new Button("Logout"),
            //booking
            seatButton[] = {new Button("A1"), new Button("A2"), new Button("A3"), new Button("A4"), new Button("A5"), new Button("A6"),
                //index 6
                new Button("B1"), new Button("B2"), new Button("B3"), new Button("B4"), new Button("B5"), new Button("B6"),
                //index 12
                new Button("C1"), new Button("C2"), new Button("C3"), new Button("C4"), new Button("C5"), new Button("C6"),},
            backBookingButton = new Button("<<BACK"),
            nextBookingButton = new Button("NEXT>>"),
            //historyPage
            backHistoryButton = new Button("<<BACK"),
            nextCartButton = new Button("NEXT>>");

    ListView orderListView = new ListView();
    ListView historyListView = new ListView();

    private void Cart() {
        VBox center = new VBox();
        center.setSpacing(5);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));
//top
        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text text = new Text("Cart");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

//mid
        StackPane mid = new StackPane();

        mid.setMinHeight(200);
        mid.getChildren().add(orderListView);

//bottom
        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        nextCartButton.setMinSize(100, 40);
        hb.getChildren().addAll(nextCartButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void History() {
        VBox center = new VBox();
        center.setSpacing(5);
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));

        StackPane top = new StackPane();
        top.setMinHeight(30);
        Text text = new Text("History");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

        StackPane mid = new StackPane();

        mid.setMinHeight(200);
        mid.getChildren().add(historyListView);

        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        backHistoryButton.setMinSize(100, 40);
        hb.getChildren().addAll(backHistoryButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void Booking() {
        VBox center = new VBox();
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));
//top

        StackPane top = new StackPane();

        top.setPadding(new Insets(20, 0, 0, 0));
        top.setMinHeight(30);
        Text text = new Text("Seclect Your Destination");
        text.setFont(Font.font(30));
        top.getChildren().addAll(text);

//mid
        StackPane mid = new StackPane();
        mid.setMinHeight(250);

        HBox hbox1 = new HBox();

        Label sourceLabel = new Label("From"),
                distinationLabel = new Label("To"),
                dateLabel = new Label("Date"),
                timeLabel = new Label("Time"),
                priceLabel = new Label("Price Per sit: ");

        sourceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");
        distinationLabel.setStyle("-fx-font: normal bold 20px 'serif' ");
        dateLabel.setStyle("-fx-font: normal bold 20px 'serif' ");
        timeLabel.setStyle("-fx-font: normal bold 20px 'serif' ");
        priceLabel.setStyle("-fx-font: normal bold 20px 'serif' ");
        price.setStyle("-fx-font: normal bold 20px 'serif' ");

        hbox1.setAlignment(Pos.CENTER);
        hbox1.setSpacing(15);

        VBox vb1 = new VBox(),
                vb2 = new VBox(),
                vb3 = new VBox(),
                vb4 = new VBox(),
                vb5 = new VBox();

        vb1.setAlignment(Pos.CENTER);
        vb1.getChildren().addAll(sourceLabel, locationComboBox);
        vb2.setAlignment(Pos.CENTER);
        vb2.getChildren().addAll(distinationLabel, distinationComboBox);
        vb3.setAlignment(Pos.CENTER);
        vb3.getChildren().addAll(dateLabel, date);
        vb4.setAlignment(Pos.CENTER);
        vb4.getChildren().addAll(timeLabel, time);
        vb5.setAlignment(Pos.CENTER);
        vb5.getChildren().addAll(priceLabel, price);

        locationComboBox.getItems().clear();
        locationComboBox.getItems().add("Kulai");
        locationComboBox.getItems().add("JohorBahru");
        locationComboBox.getSelectionModel().select(0);

        distinationComboBox.getItems().clear();
        distinationComboBox.getItems().add("Kuala Lumpur");
        distinationComboBox.getItems().add("Batu Pahat");
        distinationComboBox.getSelectionModel().select(0);

        date.setMaxWidth(126);
        date.setValue(LocalDate.now().plusDays(1));

        time.setMaxWidth(100);
        time.getItems().clear();
        time.getItems().add("8.00AM");
        time.getItems().add("12.00PM");
        time.getItems().add("4.00PM");
        time.getItems().add("8.00PM");
        hbox1.getChildren().addAll(vb1, vb2, vb3, vb4, vb5);

        HBox hbox3 = new HBox();

        hbox3.setAlignment(Pos.CENTER);
        hbox3.setSpacing(150);

        Button emptySeatButton = new Button("available");
        emptySeatButton.setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
        emptySeatButton.setMinSize(100, 60);

        Button bookedSeatButton = new Button("booked");
        bookedSeatButton.setStyle("-fx-background-color: Red;-fx-text-fill: white;-fx-font-size: 20px");
        bookedSeatButton.setMinSize(100, 60);
        bookedSeatButton.setDisable(true);

        Button selectedSeatButton = new Button("selected");
        selectedSeatButton.setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
        selectedSeatButton.setMinSize(100, 60);

        hbox3.getChildren().addAll(emptySeatButton, bookedSeatButton, selectedSeatButton);

        HBox hbox4 = new HBox();

        hbox4.setSpacing(38);
        HBox hbox5 = new HBox();

        hbox5.setSpacing(38);
        HBox hbox6 = new HBox();

        hbox6.setSpacing(38);
        for (int i = 0; i < seatButton.length; i++) {
            seatButton[i].setDisable(true);
            seatButton[i].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
            seatButton[i].setMinSize(75, 40);

            if (i < 6) {
                hbox4.getChildren().add(seatButton[i]);

            } else if (i < 12) {
                hbox5.getChildren().add(seatButton[i]);

            } else if (i > 11) {
                hbox6.getChildren().add(seatButton[i]);

            }

        }
        GridPane gPane = new GridPane();
        gPane.add(hbox1, 0, 1);
        gPane.add(hbox3, 0, 2);
        gPane.add(hbox4, 0, 3);
        gPane.add(hbox5, 0, 4);
        gPane.add(hbox6, 0, 5);

        //Setting size for the pane 
        gPane.setPrefHeight(360);

        //Setting the padding  
        //gPane.setPadding(new Insets(10, 10, 10, 10)); 
        //Setting the vertical and horizontal gaps between the columns 
        gPane.setVgap(20);
        //gPane.setHgap(20);       

        //Setting the Grid alignment 
        gPane.setAlignment(Pos.TOP_CENTER);

        mid.getChildren().add(gPane);

//bottom
        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        backBookingButton.setMinSize(100, 40);
        nextBookingButton.setMinSize(100, 40);
        hb.getChildren().addAll(backBookingButton, nextBookingButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);

    }

    private void userMenu() {
        VBox center = new VBox();
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));
//top
        StackPane top = new StackPane();
        top.setPadding(new Insets(20, 0, 0, 0));
        top.setMinHeight(30);
        Text text = new Text("Menu");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

//mid
        StackPane mid = new StackPane();
        mid.setMinHeight(220);
        VBox vb1 = new VBox();
        userName.setFont(Font.font(30));
        userName.setText("Welcome!! \n"+user[userTemp].getName());
        mid.getChildren().add(userName);

//bottom
        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.getChildren().clear();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(90);
        startBookingButton.setMinSize(150, 80);
        viewHistoryButton.setMinSize(150, 80);
        logoutButton.setMinSize(150, 80);
        hb.getChildren().addAll(startBookingButton, viewHistoryButton, logoutButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void Registr() {
        VBox center = new VBox();
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));
//top
        StackPane top = new StackPane();
        top.setPadding(new Insets(20, 0, 0, 0));
        top.setMinHeight(30);
        Text text = new Text("Register");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

//mid
        StackPane mid = new StackPane();
        mid.setMinHeight(250);

        Text text1 = new Text("User Name: ");
        text1.setFont(Font.font(30));

        Text text2 = new Text("Password: ");
        text2.setFont(Font.font(30));

        Text text3 = new Text("Retype Password: ");
        text3.setFont(Font.font(30));

        userRegisterTextField.setPromptText("UserName...");
        userRegisterTextField.setPrefHeight(35);
        registerPasswordTextField.setPromptText("Password");
        registerPasswordTextField.setPrefHeight(35);
        registerRenterPasswordTextField.setPromptText("retype Password");
        registerRenterPasswordTextField.setPrefHeight(35);

        GridPane gridPane = new GridPane();

        gridPane.setVgap(20);
        gridPane.setHgap(20);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(text1, 0, 0);
        gridPane.add(userRegisterTextField, 1, 0);
        gridPane.add(text2, 0, 1);
        gridPane.add(registerPasswordTextField, 1, 1);
        gridPane.add(text3, 0, 2);
        gridPane.add(registerRenterPasswordTextField, 1, 2);
        mid.getChildren().add(gridPane);

//bottom
        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        backToLoginButton.setMinSize(100, 40);
        confirmRegisterButton.setMinSize(100, 40);
        hb.getChildren().addAll(backToLoginButton, confirmRegisterButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);
    }

    private void Login() {
        VBox center = new VBox();
        center.setMinWidth(500);
        center.setPadding(new Insets(10, 25, 10, 25));
//top
        StackPane top = new StackPane();
        top.setPadding(new Insets(20, 0, 0, 0));
        top.setMinHeight(30);
        Text text = new Text("Login");
        text.setFont(Font.font(30));
        top.getChildren().add(text);

//mid
        StackPane mid = new StackPane();
        mid.setMinHeight(250);

        Text text1 = new Text("User Name: ");
        text1.setFont(Font.font(30));

        Text text2 = new Text("Password: ");
        text2.setFont(Font.font(30));

        userTextField.setPromptText("UserName...");
        userTextField.setPrefHeight(35);
        passwordTextField.setPromptText("Password");
        passwordTextField.setPrefHeight(35);

        GridPane gridPane = new GridPane();

        gridPane.setVgap(20);
        gridPane.setHgap(20);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(text1, 0, 0);
        gridPane.add(userTextField, 1, 0);
        gridPane.add(text2, 0, 1);
        gridPane.add(passwordTextField, 1, 1);

        mid.getChildren().add(gridPane);

//bottom
        StackPane bottom = new StackPane();
        HBox hb = new HBox();
        hb.setAlignment(Pos.CENTER);
        hb.setSpacing(100);
        loginButton.setMinSize(100, 40);
        registerButton.setMinSize(100, 40);
        hb.getChildren().addAll(loginButton, registerButton);
        bottom.getChildren().add(hb);

        center.getChildren().addAll(top, mid, bottom);
        root.setCenter(center);

    }

    private void WelcomeMenu() {

        VBox welcomeVB = new VBox();
        welcomeVB.setStyle("-fx-background-color:Gray");
        StackPane WelcomeSP = new StackPane();
        StackPane welcomeSP = new StackPane();
        Text a = new Text("  BusTicket ");
        a.setFill(Color.WHITE);
        a.setFont(Font.font("Bauhaus 93", 75));
        WelcomeSP.getChildren().add(a);
        welcomeVB.getChildren().addAll(WelcomeSP, welcomeSP);
        root.setTop(welcomeVB);
    }

    private void historyList(int i){
                    HBox hb1 = new HBox(300);

            GridPane gp = new GridPane();
            gp.setHgap(15);
            gp.setAlignment(Pos.CENTER);
            
                gp.getChildren().removeAll(seatButton);
                hb1.getChildren().clear();
                int a =booking[i].getUserID();
                if (a== userTemp) {

                    Text text = new Text("UserName: \n" + user[userTemp].getName());
                    text.setFont(Font.font(15));
                    Text text1 = new Text("Departure Date:\n " + booking[i].getDate().toString());
                    text1.setFont(Font.font(15));

                    Text text2;
                    text2 = new Text("Departure Time:\n " + booking[i].getTime());
                    text2.setFont(Font.font(15));

                    Text text3;
                    text3 = new Text("From: \n" + booking[i].getLocation());

                    text3.setFont(Font.font(15));

                    Text text4;
                    text4 = new Text("To: \n" + booking[i].getDestination());

                    text4.setFont(Font.font(15));

                    Text text5 = new Text("Total Seats booked:\n " + String.valueOf(booking[i].getSeatCount()));
                    text5.setFont(Font.font(15));

                    ArrayList<String> list = booking[i].getSeats();
                    String str;

                   System.out.println(list.get(0).toString()+booking[i].getSeatCount());
                    Text[] textText = new Text[18];
                    int y = 0;
                    for (int j = 0; j <booking[i].getSeatCount(); j++) {
                        str = (list.get(j).toString());
                        System.out.println(str);
                        textText[j] = new Text(str);
                        gp.add(textText[j], 5, y);
                        y++;
                    }

                    Text text6 = new Text("Price Per Sit:\nRM " + String.valueOf(booking[i].getPrice()));
                    text6.setFont(Font.font(15));
                    Text text7 = new Text("Total:\nRM " + String.valueOf(booking[i].calPrice()));
                    text7.setFont(Font.font(15));
//
//                    Text text8 = new Text(pizza.calculatePrice());
//                    text8.setFont(Font.font(15));
                    gp.add(text, 0, 0);
                    gp.add(text1, 1, 0);
                    gp.add(text2, 2, 0);
                    gp.add(text3, 3, 0);
                    gp.add(text4, 3, 1);
                    gp.add(text5, 4, 0);
                    gp.add(text6, 6, 0);
                    gp.add(text7, 7, 0);
//                    gp.add(text8, 4, 0);

                    hb1.setAlignment(Pos.CENTER_LEFT);
                    hb1.setPrefWidth(500);
                    hb1.getChildren().addAll(gp);
                    historyListView.getItems().add(hb1);
                
            }

    }
    @Override
    public void start(Stage primaryStage) {
        for (int i = 0; i < seat.length; i++) {
            seat[i] = true;
            Seat[i] = true;
        }
        WelcomeMenu();
        Login();
        root.setStyle("-fx-background-color:White");

        scene = new Scene(root);

        primaryStage.setTitle("BusTicket");
        //icon
        //Image busIcon = new Image("/image/busIcon.png", 100, 100, false, false);
        //primaryStage.getIcons().add(busIcon);
        primaryStage.setScene(scene);
        primaryStage.setHeight(600);
        primaryStage.setWidth(700);
        primaryStage.show();

//cart page
        nextCartButton.setOnAction(e -> {
            double m;
            boolean c = false;
            do {
                try {
                    m = Double.parseDouble(JOptionPane.showInputDialog("Total Price: RM " + booking[countBooking - 1].calPrice()));
                    System.out.println(m);
                    if (m < booking[countBooking - 1].calPrice()) {
                        JOptionPane.showMessageDialog(null, "Must be more than Price");
                    } else if (m >= booking[countBooking - 1].calPrice()) {
                        m = m - booking[countBooking - 1].calPrice();
                        JOptionPane.showMessageDialog(null, "!Thank You!\nReturn Balance: RM " + m);
                        c = true;

                    }
                } catch (NumberFormatException | NullPointerException f) {
                    JOptionPane.showMessageDialog(null, "Please insert correct value");
                }

            } while (!c);

            userMenu();

        });
        //login page
        loginButton.setOnAction(e -> {

            if (userTextField.getText().isEmpty() || passwordTextField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Pless fill all the Information");

            } else {
                boolean a = false;
                for (int i = 0; i < countUser; i++) {
                    if (user[i].getName().equals(userTextField.getText())) {
                        if (user[i].getPassword().equals(passwordTextField.getText())) {
                            a = true;
                            userTemp = i;
                            break;
                        }
                    }
                }
                if (a == true) {

                    userMenu();
                    JOptionPane.showMessageDialog(null, "Welcome " + user[userTemp].getName());
                } else {
                    JOptionPane.showMessageDialog(null, "User Name or Password Incorrect");
                }
            }

        });

        registerButton.setOnAction(e -> {
            userRegisterTextField.clear();
            registerPasswordTextField.clear();
            registerRenterPasswordTextField.clear();
            Registr();
        });

        //register page
        backToLoginButton.setOnAction(e -> {
            userTextField.clear();
            passwordTextField.clear();
            Login();
        });

        confirmRegisterButton.setOnAction(e -> {
            userTextField.clear();
            passwordTextField.clear();
            if (userRegisterTextField.getText().isEmpty() || registerPasswordTextField.getText().isEmpty() || registerRenterPasswordTextField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Pless fill all the Information");

            } else if (registerPasswordTextField.getText().equals(registerRenterPasswordTextField.getText())) {
                if (countUser == 0) {
                    user[countUser] = new User(userRegisterTextField.getText(), registerPasswordTextField.getText());
                    JOptionPane.showMessageDialog(null, "Register Sucessful");
                    countUser += 1;
                    Login();
                } else {
                    boolean a = true;
                    for (int i = 0; i < countUser; i++) {
                        if (user[i].getName().equals(userRegisterTextField.getText())) {
                            a = false;
                            break;
                        }
                    }
                    if (a == true) {
                        user[countUser] = new User(userRegisterTextField.getText(), registerPasswordTextField.getText());
                        JOptionPane.showMessageDialog(null, "Register Sucessful");
                        countUser += 1;

                        Login();
                    } else {
                        JOptionPane.showMessageDialog(null, "UserName Has been Taken");
                    }

                }

            } else {
                JOptionPane.showMessageDialog(null, "password not match");
            }

        });

        //userMenu
        logoutButton.setOnAction(e -> {
            userTextField.clear();
            passwordTextField.clear();
            Login();
        });

        startBookingButton.setOnAction(e -> {

            Booking();
        });

        viewHistoryButton.setOnAction(e -> {
             historyListView.getItems().clear();
for (int i = 0; i < countBooking; i++) {
    historyList(i);
   
}
            History();

        });

        //history Page
        backHistoryButton.setOnAction(e -> {
            userMenu();
            time.setValue("Select a Time");
        });

        //booking page
        backBookingButton.setOnAction(e -> {
            userMenu();
            time.setValue("Select a Time");

        });

        nextBookingButton.setOnAction(e -> {
            orderListView.getItems().clear();
            int b = JOptionPane.showConfirmDialog(null, "Confirm order??\nCannot Cancle After", "confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (b == JOptionPane.YES_OPTION) {
                boolean a = true;
                for (int i = 0; i < Seat.length; i++) {
                    if (Seat[i] == false) {
                        a = false;
                    }
                }
                if (a == true) {
                    JOptionPane.showMessageDialog(null, "Please Select Seat Before continue");
                } else if (a == false) {

                    String seatTemp[] = new String[18];
                    int seatCount = 0;
                    for (int i = 0; i < Seat.length; i++) {
                        if (Seat[i] == false) {
                            seatTemp[seatCount] = seatButton[i].getText();
                            seatCount++;

                        }
                    }
                    boolean seatBoolean[] = Seat.clone();
                    booking[countBooking] = new Booking(userTemp, locationComboBox.getValue().toString(), distinationComboBox.getValue().toString(), date.getValue(), time.getValue().toString(), seatBoolean, seatTemp, seatCount, Price);

                    System.out.println(booking[countBooking].getDate() + booking[countBooking].getDestination() + booking[countBooking].getTime() + booking[countBooking].getLocation() + booking[countBooking].getUserID() + countBooking + booking[countBooking].getSeat() + booking[countBooking]);

                    time.setValue("Select a Time");

                    HBox hb1 = new HBox(300);

                    GridPane gp = new GridPane();

                    Text text = new Text("UserName: \n" + user[userTemp].getName());
                    text.setFont(Font.font(15));
                    Text text1 = new Text("Departure Date:\n " + booking[countBooking].getDate().toString());
                    text1.setFont(Font.font(15));

                    Text text2;
                    text2 = new Text("Departure Time:\n " + booking[countBooking].getTime());
                    text2.setFont(Font.font(15));

                    Text text3;
                    text3 = new Text("From: \n" + booking[countBooking].getLocation());

                    text3.setFont(Font.font(15));

                    Text text4;
                    text4 = new Text("To: \n" + booking[countBooking].getDestination());

                    text4.setFont(Font.font(15));

                    Text text5 = new Text("Total Seats booked:\n " + String.valueOf(seatCount));
                    text5.setFont(Font.font(15));

                    ArrayList<String> list = booking[countBooking].getSeats();
                    String str;
                    Text[] textText = new Text[18];
                    int y = 0;
                    for (int i = 0; i < seatCount; i++) {
                        str = (list.get(i).toString());
                        System.out.println(str);
                        textText[i] = new Text(str);
                        gp.add(textText[i], 5, y);
                        y++;
                    }

                    Text text6 = new Text("Price Per Sit:\nRM " + String.valueOf(booking[countBooking].getPrice()));
                    text6.setFont(Font.font(15));
                    Text text7 = new Text("Total:\nRM " + String.valueOf(booking[countBooking].calPrice()));
                    text7.setFont(Font.font(15));
//
//                    Text text8 = new Text(pizza.calculatePrice());
//                    text8.setFont(Font.font(15));
                    gp.add(text, 0, 0);
                    gp.add(text1, 1, 0);
                    gp.add(text2, 2, 0);
                    gp.add(text3, 3, 0);
                    gp.add(text4, 3, 1);
                    gp.add(text5, 4, 0);
                    gp.add(text6, 6, 0);
                    gp.add(text7, 7, 0);
//                    gp.add(text8, 4, 0);

                    gp.setHgap(15);
                    gp.setAlignment(Pos.CENTER);
                    hb1.setAlignment(Pos.CENTER_LEFT);
                    hb1.setPrefWidth(500);
                    hb1.getChildren().addAll(gp);
                    orderListView.getItems().add(hb1);

                    countBooking += 1;
                    Cart();

                }

            } else if (b == JOptionPane.NO_OPTION) {

            }

        });

        locationComboBox.setOnAction(e -> {
            time.setValue("Select a Time");
            for (int i = 0; i < seatButton.length; i++) {
                seatButton[i].setDisable(true);
                seatButton[i].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                seat[i] = true;

            }
        });
        distinationComboBox.setOnAction(e -> {
            time.setValue("Select a Time");
            for (int i = 0; i < seatButton.length; i++) {
                seatButton[i].setDisable(true);
                seatButton[i].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                seat[i] = true;

            }
        });

        //set diseaable date befor today
        date.setDayCellFactory(param -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.compareTo(LocalDate.now()) < 1);
            }
        });

        date.setOnAction(e -> {
            time.requestFocus();
            time.setValue("Select a Time");
            for (int i = 0; i < seatButton.length; i++) {
                seatButton[i].setDisable(true);
                seatButton[i].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                seat[i] = true;

            }
        });

        time.setOnAction(e -> {

            if (time != null) {
                if (locationComboBox.getValue().toString().equals("Kulai") && distinationComboBox.getValue().toString().equals("Kuala Lumpur")) {
                    Price = 30;
                    price.setText("30");
                } else if (locationComboBox.getValue().toString().equals("Kulai") && distinationComboBox.getValue().toString().equals("Batu Pahat")) {
                    Price = 25;
                    price.setText("25");
                } else if (locationComboBox.getValue().toString().equals("JohorBahru") && distinationComboBox.getValue().toString().equals("Kuala Lumpur")) {

                    Price = 38;
                    price.setText("38");
                } else if (locationComboBox.getValue().toString().equals("JohorBahru") && distinationComboBox.getValue().toString().equals("Batu Pahat")) {

                    Price = 31;
                    price.setText("30");
                }

                for (int i = 0; i < seatButton.length; i++) {
                    seatButton[i].setDisable(false);
                    seatButton[i].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[i] = true;
                    Seat[i] = true;

                }

                if (countBooking == 0) {

                    for (int i = 0; i < seatButton.length; i++) {
                        seatButton[i].setDisable(false);
                        seatButton[i].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                        seat[i] = true;
                        Seat[i] = true;
                    }
                } else {

                    for (int i = 0; i < countBooking; i++) {

                        if (booking[i].getTime().equals(time.getValue().toString())
                                && booking[i].getLocation().equals(locationComboBox.getValue().toString())
                                && booking[i].getDestination().equals(distinationComboBox.getValue().toString())
                                && booking[i].getDate().equals(date.getValue())) {

                            System.out.println("success");
                            boolean seatBooking[] = booking[i].getSeat();
                            for (int j = 0; j < seatBooking.length; j++) {

                                if (seatBooking[j] == false) {
                                    seatButton[j].setDisable(true);
                                    seatButton[j].setStyle("-fx-background-color: Red;-fx-text-fill: white;-fx-font-size: 20px");
                                    seat[j] = false;

                                }
                            }
                        }

                    }

                }

            }

        });

        //a
        seatButton[0].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[0] == true) {
                    seatButton[0].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[0] = false;
                    Seat[0] = false;
                } else if (seat[0] == false) {
                    seatButton[0].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[0] = true;
                    Seat[0] = true;
                }
            }

        });

        seatButton[1].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {
                if (seat[1] == true) {
                    seatButton[1].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[1] = false;
                    Seat[1] = false;
                } else if (seat[1] == false) {
                    seatButton[1].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[1] = true;
                    Seat[1] = true;
                }
            }
        });
        seatButton[2].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[2] == true) {
                    seatButton[2].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[2] = false;
                    Seat[2] = false;
                } else if (seat[2] == false) {
                    seatButton[2].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[2] = true;
                    Seat[2] = true;
                }
            }
        });
        seatButton[3].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[3] == true) {
                    seatButton[3].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[3] = false;
                    Seat[3] = false;
                } else if (seat[3] == false) {
                    seatButton[3].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[3] = true;
                    Seat[3] = true;
                }
            }
        });
        seatButton[4].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[4] == true) {
                    seatButton[4].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[4] = false;
                    Seat[4] = false;
                } else if (seat[4] == false) {
                    seatButton[4].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[4] = true;
                    Seat[4] = true;
                }
            }
        }
        );
        seatButton[5].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[5] == true) {
                    seatButton[5].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[5] = false;
                    Seat[5] = false;
                } else if (seat[5] == false) {
                    seatButton[5].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[5] = true;
                    Seat[5] = true;
                }
            }
        }
        );

        //b
        seatButton[6].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[6] == true) {
                    seatButton[6].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[6] = false;
                    Seat[6] = false;
                } else if (seat[6] == false) {
                    seatButton[6].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[6] = true;
                    Seat[6] = true;
                }
            }
        }
        );
        seatButton[7].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[7] == true) {
                    seatButton[7].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[7] = false;
                    Seat[7] = false;
                } else if (seat[7] == false) {
                    seatButton[7].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[7] = true;
                    Seat[7] = true;
                }
            }
        }
        );
        seatButton[8].setOnAction(e -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[8] == true) {
                    seatButton[8].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[8] = false;
                    Seat[8] = false;
                } else if (seat[8] == false) {
                    seatButton[8].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[8] = true;
                    Seat[8] = true;
                }
            }
        }
        );
        seatButton[9].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[9] == true) {
                    seatButton[9].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[9] = false;
                    Seat[9] = false;
                } else if (seat[9] == false) {
                    seatButton[9].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[9] = true;
                    Seat[9] = true;
                }
            }
        }
        );
        seatButton[10].setOnAction(e -> {

            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[10] == true) {
                    seatButton[10].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[10] = false;
                    Seat[10] = false;
                } else if (seat[10] == false) {
                    seatButton[10].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[10] = true;
                    Seat[10] = true;
                }
            }
        }
        );
        seatButton[11].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[11] == true) {
                    seatButton[11].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[11] = false;
                    Seat[11] = false;
                } else if (seat[11] == false) {
                    seatButton[11].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[11] = true;
                    Seat[11] = true;
                }
            }
        }
        );

        //c
        seatButton[12].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[12] == true) {
                    seatButton[12].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[12] = false;
                    Seat[12] = false;
                } else if (seat[12] == false) {
                    seatButton[12].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[12] = true;
                    Seat[12] = true;
                }
            }
        }
        );
        seatButton[13].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[13] == true) {
                    seatButton[13].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[13] = false;
                    Seat[13] = false;
                } else if (seat[13] == false) {
                    seatButton[13].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[13] = true;
                    Seat[13] = true;
                }
            }
        }
        );
        seatButton[14].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[14] == true) {
                    seatButton[14].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[14] = false;
                    Seat[14] = false;
                } else if (seat[14] == false) {
                    seatButton[14].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[14] = true;
                    Seat[14] = true;

                }
            }
        }
        );
        seatButton[15].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[15] == true) {
                    seatButton[15].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[15] = false;
                    Seat[15] = false;
                } else if (seat[15] == false) {
                    seatButton[15].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[15] = true;
                    Seat[15] = true;
                }
            }
        }
        );
        seatButton[16].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[16] == true) {
                    seatButton[16].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[16] = false;
                    Seat[16] = false;
                } else if (seat[16] == false) {
                    seatButton[16].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[16] = true;
                    Seat[16] = true;
                }
            }
        }
        );
        seatButton[17].setOnAction(e
                -> {
            if (time.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Please Select Time");
            } else {

                if (seat[17] == true) {
                    seatButton[17].setStyle("-fx-background-color: Green;-fx-text-fill: white;-fx-font-size: 20px");
                    seat[17] = false;
                    Seat[17] = false;
                } else if (seat[17] == false) {
                    seatButton[17].setStyle("-fx-background-color: LightGrey;-fx-font-size: 20px");
                    seat[17] = true;
                    Seat[17] = true;
                }
            }
        }
        );

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
