/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

import java.util.*;

/**
 *
 * @author LOL87
 */
public class Question3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner input=new Scanner(System.in);         
       System.out.print("Enter a value for feet:");         
       double feet = input.nextDouble();          
       double meters = feet*0.305;         
       System.out.print(feet+" feet is " +meters+ "meters"); 
        
    }
    
}
