/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computearea;

/**
 *
 * @author LOL87
 */
import java.util.*;
public class ComputeArea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        //Scanner (___)=new Scanner(System.in);
        System.out.print("Enter the radius and length of a cylinder :");
        //System.out.println('Enter Radius :");
        //Doing this will display the [Enter Radius :]word     
        double radius = input.nextDouble();
        double length = input.nextDouble();
        //double is the Method and (__) set a interge for new datatype
        double area = radius*radius*3.1415;
        //enter a formula for the radius
        double volume=(area*length);
        System.out.println("The area is "+ area);
        System.out.println("The volume is "+ volume);
        //print out !!!!
        
    }
    
}
