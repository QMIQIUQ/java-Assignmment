/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupprojecadvancejava;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author MIQIU
 */
public class Booking {

    private int userID;
    private String location;
    private String Destination;
    private LocalDate date;
    private String Time;
    private double Price;
    private ArrayList<String> seats = new ArrayList();
    private int seatCount;
    private boolean[] seat = new boolean[18];

    public Booking(int userID, String location, String Destination, LocalDate date, String Time, boolean[] seat, String[] seats, int seatCount, double Price) {

        this.userID = userID;
        this.location = location;
        this.Destination = Destination;
        this.date = date;
        this.Time = Time;
        this.Price = Price;
        this.seat = seat;
        
        this.seatCount = seatCount;
        setSeats(seats);
    }

    public void setSeats(String[] seats) {
        
        for(int i = 0;i<seatCount;i++){
        this.seats.add(seats[i]);
        }
        
    }

    public int getSeatCount() {
        return seatCount;
    }

    public boolean[] getSeat() {
        return seat;
    }

    public ArrayList<String> getSeats() {
        return seats;
    }



    public int getUserID() {
        return userID;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getDestination() {
        return Destination;
    }

    public String getLocation() {
        return location;
    }

    public double getPrice() {
        return Price;
    }

    public String getTime() {
        return Time;
    }
    
        public double calPrice(){
        return Price*seatCount;
    }

}
