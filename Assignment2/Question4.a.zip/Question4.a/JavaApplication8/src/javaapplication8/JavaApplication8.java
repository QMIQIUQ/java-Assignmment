/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication8;
import javax.swing.JOptionPane;
/**
 *
 * @author LOL87
 */
public class JavaApplication8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String name= JOptionPane.showInputDialog(null,"Enter employee's name","Financial application: payroll",JOptionPane.INFORMATION_MESSAGE);
        String HoursWork = JOptionPane.showInputDialog(null,"Enter number of hours work in a week","Financial application: payroll",JOptionPane.INFORMATION_MESSAGE);
        String PayRate = JOptionPane.showInputDialog(null,"Enter hourly pay rate","Financial application: payroll",JOptionPane.INFORMATION_MESSAGE);
        String FederalTax = JOptionPane.showInputDialog(null,"Enter federal tax withholding rate","Financial application: payroll",JOptionPane.INFORMATION_MESSAGE);
        String StateTax = JOptionPane.showInputDialog(null,"Enter state tax withholding rate","Financial application: payroll",JOptionPane.INFORMATION_MESSAGE);
        double GrossPay =  Double.parseDouble(HoursWork)* Double.parseDouble(PayRate);
        double Federa = GrossPay*Double.parseDouble(FederalTax);
        double State = GrossPay*Double.parseDouble(StateTax);
        double Deuction = Federa+State;
        double NetPay = GrossPay-Deuction;
        JOptionPane.showMessageDialog(null, "Employee name: "+name+"\nHours Worked: "+HoursWork+"\nPay Rate: "+"$"+PayRate+"\nGross Pay "+"$"+GrossPay+"(n)Deuctions:"+"\n   Federa Withholding (20%): "+"$"+Federa+"\n   State Withholding (9.0%): "+"$"+State+"\n   Total Deuction: "+"$"+Deuction+"\nNet Pay: "+"$"+NetPay,"Financial application: payroll",JOptionPane.INFORMATION_MESSAGE);
   
    }
    
}
