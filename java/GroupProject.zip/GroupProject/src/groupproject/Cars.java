/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;

import java.util.Scanner;

/**
 *
 * @author dogaa
 */
import java.util.*;
public class Cars {
     public static void Cars(boolean[] state){
        Scanner input = new Scanner(System.in);
        String[] name = {"Produa viva(A)\t\t","Produa Axia(A)\t\t","Produa Myvi(A)\t\t","Produa Alza S(A)\t","Produa Alza SE(A)/Advance","Perodua Alza (A)(MPV 7 Seater)",
            "Produa Axia(M)\t\t","Produa Myvi 1.5 XTreme(M)"};
        
        String[] Price = {"RM120","RM130","RM150","RM180","RM200","RM500",
            "RM110","RM130"};
        
        for(int a=0;a<name.length;a++){
            System.out.print(name[a]+"\t"+Price[a]+"\t");
            
            if (state[a]==true){
                System.out.println("Avalible");
            }else{
                System.out.println("Not Avalible");
            }
        }
        System.out.println("------------------------------------------------");
        Menu.Menu1(state);
    } 
    public static void Produa(){
        Scanner input = new Scanner(System.in);
        String[] ProduaA = {"Produa viva","Produa Axia","Produa Myvi","Produa Alza S","Produa Alza SE/Advance","Perodua Alza (MPV 7 Seater)"};
        String[] PriceA = {"Rm120","Rm130","Rm150","Rm180","Rm200","Rm500"};
        
        String[] ProduaM = {"Produa Axia","Produa Myvi 1.5 XTreme"};
        String[] PriceM = {"Rm110","Rm130"};
        
        
        for(int a=0;a<ProduaA.length;a++){
           System.out.println(ProduaA+"\t\t"+PriceA); 
        }
        
    }
}

