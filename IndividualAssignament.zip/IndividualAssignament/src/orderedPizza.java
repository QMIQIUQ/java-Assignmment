
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MIQIU
 */
public class orderedPizza {

    private String Name;
    private String phoneNumber;
    private int Size;
    private boolean[] toppings = new boolean[3];
    private String address;
    private double totalprice = 0;
        
    public orderedPizza(String Name, String phoneNumber, int Size, boolean[] toppings, String address) {
        setName(Name);
        setPhoneNumber(phoneNumber);
        setSize(Size);
        setToppings(toppings);
        setAddress(address);
    }

    public String getName() {
        return Name;
    }

    private void setName(String Name) {
        this.Name = Name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    private void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getSize() {
        String a="";
        switch (Size) {
            case 0:
                a = "Large";
                totalprice += 12;
                break;
            case 1:
                a = "Medium";
                totalprice += 12;
                break;
            case 2:
                a = "Small";
                totalprice += 12;
                break;
            default: 
                JOptionPane.showMessageDialog(null, "Size Error");
                break;

        };

        return a;
    }

    private void setSize(int Size) {
        this.Size = Size;
    }

    public boolean[] getToppings() {
        return toppings;
    }

    private void setToppings(boolean[] toppings) {
        this.toppings = toppings;
    }

    public String getAddress() {
        return address;
    }

    private void setAddress(String address) {
        this.address = address;
    }
    
    public String calculatePrice(){
        for(int i = 0;i<toppings.length;i++){
            if(toppings[i]){
                totalprice+=2;
            }
        };
        return "RM"+totalprice;
        
    }

    public double getTotalprice() {
        return totalprice;
    }
   
}
