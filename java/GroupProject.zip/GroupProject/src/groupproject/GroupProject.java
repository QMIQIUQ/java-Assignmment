/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;

/**
 *
 * @author dogaa
 */
import java.util.*;
public class GroupProject {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        promotion promotion = new promotion();
        type type = new type();
        person person = new person();
        Cars Cars = new Cars();
        Menu Menu = new Menu();
        
        int[] cartype = new int[6] ;
        
        int[] state1 = new int [8];
        boolean[] state = new boolean[8];
        state[0] = true;
        
        for(int a=0;a<state1.length;a++){
            state1[a] += Math.random()*5;
            System.out.println(state1[a]);
            }
        for(int a=0;a<state.length;a++){
            if(state1[a]==0){
                state[a] = false;
            }else{
                state[a] = true; 
            }
          System.out.println(state[a]);  
        }
        
        Menu.Menu(state);
        
        
        
        
        System.out.println(cartype[0]);
        cartype[1] = type.type();
        cartype[2] = person.person();
        
    }
    
}

