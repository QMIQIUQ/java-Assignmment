/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sections;

/**
 *
 * @author Jackson Ang D190104B 2019/05/17
 * (Count positive and negative numbers and compute the average of numbers) 
 */
import java.util.*;
public class Sections {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       Scanner input = new Scanner(System.in); 
       
       double integer,average,total;
       int positive,negative,count;
       positive = 0;
       negative = 0;
       total = 0;
       count = 0;
       
       System.out.print("Enter an integer, the input ends if it is 0: ");
       do{
           
           integer = input.nextDouble();
           if(integer>0){
               positive++;
               count++;
               total+=integer;
           }else{
           if(integer<0){
               negative++;
               count++;
               total+=integer;
           }
           }           
        }while(integer != 0);
       
        average = total/count;
        if(count != 0 ){
        System.out.print("The number of positives is "+positive+"\n");
        System.out.print("The number of nagatives is "+negative+"\n");
        System.out.print("The total is "+total+"\n");
        System.out.print("The average is "+average+"\n");
        }else{
            System.out.print("No numbers are entered except 0\n");
        }    
    }
}
       
    

