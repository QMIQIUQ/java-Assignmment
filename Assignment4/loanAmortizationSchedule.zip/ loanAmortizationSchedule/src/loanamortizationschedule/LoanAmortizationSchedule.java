/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loanamortizationschedule;

/**
 *
 * @author Jackson Ang D190104B 2019/05/20
 *  (Financial application: compare loans with various interest rates) 
 */
import java.util.*;
public class LoanAmortizationSchedule {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Loan Amount: ");
        double la = input.nextDouble();
        System.out.print("Number of years: ");
        double y = input.nextDouble();
        
        
        System.out.print("Intrest Rate\tMonthly Payment\t Total Payment\n");
        for(double i = 5.0;8 >= i;i+=0.125){
            System.out.printf("%-1.3f",i);
            System.out.print("%\t\t");
            double mir = i/1200;
            double mp = la * mir / (1- 1 / Math.pow(1 + mir, y * 12));
		System.out.printf("%-1.2f",mp);
                System.out.print("\t\t ");
		System.out.printf("%-1.2f\n",(mp*12)*y);
            System.out.println();
        }
    }
    
}
