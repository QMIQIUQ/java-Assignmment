/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package displaypyramid;

/**
 *
 * @author Jackson Ang D190104B 2019/05/18
 * Display pyramid
 */
import java.util.*;
public class DisplayPyramid {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of lines: ");
        int inp = input.nextInt();
        int a,b,c,d,e,f;
        
        for(a=1;a<=(inp);a++){
            for(b=1;b<=(inp-a);b++){
                System.out.print("   ");
            }for(c=a;c>=1;c--){
               System.out.print("   ");             
           }
            for(d=1;d<=(inp-a);d++){
                System.out.print("   ");
            }for(e=a;e>=1;e--){
               System.out.print(e+"  ");             
           }for(f=2;f<=a;f++){
                System.out.print(f+"  ");
           }
            System.out.println();
        }        
        }
    }
    


    
