/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication8;
import java.util.*; 
/**
 *
 * @author LOL87
 */
public class JavaApplication8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                      
           Scanner input=new Scanner(System.in);         
           System.out.print("Enter employee's name: ");         
           String name= input.next();         
           System.out.print("Enter number of hours work in a week: ");         
           double HoursWork = input.nextDouble();         
           System.out.print("Enter hourly pay rate: ");        
           double PayRate = input.nextDouble();         
           System.out.print("Enter federal tax withholding rate: ");         
           double FederalTax = input.nextDouble();         
           System.out.print("Enter state tax withholding rate: ");         
           double StateTax = input.nextDouble();         
           double GrossPay = HoursWork*PayRate;         
           double Federa = GrossPay*FederalTax;         
           double State = GrossPay*StateTax;         
           double Deuction = Federa+State;         
           double NetPay = GrossPay-Deuction;         
           System.out.println("Employee name:\t"+name);         
           System.out.println("Hours Worked\t:"+HoursWork);         
           System.out.println("Pay Rate:\t"+"$"+PayRate);         
           System.out.println("Gross Pay\t"+"$"+GrossPay);         
           System.out.println("Deuctions:");         
           System.out.println("\tFedera Withholding (20%):\t"+"$"+Federa);         System.out.println("\tState Withholding (9.0%):\t"+"$"+State);         System.out.println("\tTotal Deuction:\t"+"$"+Deuction);         
           System.out.println("Net Pay:\t"+"$"+NetPay);
           }
    }
    

